# Build the Docker image locally
docker build -t forestierherzig/mockmock .
